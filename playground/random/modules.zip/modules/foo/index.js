console.log('importing foo');
import * as bar from 'bar';
console.log(bar);
